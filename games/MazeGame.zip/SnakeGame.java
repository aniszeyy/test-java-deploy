package games;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SnakeGame extends JPanel implements KeyListener {
    private int x = 0;
    private int y = 0;
    private int[] snake = new int[100];
    private boolean gameOver = false;

    public SnakeGame() {
        setPreferredSize(new Dimension(400, 400));
        setBackground(Color.BLACK);
        addKeyListener(this);
        setFocusable(true);

        // Initialize snake position
        snake[0] = x;
        snake[1] = y;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.WHITE);
        for (int i = 0; i < snake.length; i++) {
            if (i == 0) {
                g.fillRect(snake[i], snake[i + 1] * 20, 20, 20);
            } else {
                g.fillRect(snake[i - 1], snake[i] * 20, 20, 20);
            }
        }

        // Draw food
        g.fillOval(x * 20, y * 20, 20, 20);
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_UP && snake[1] > 0) y--;
        else if (e.getKeyCode() == KeyEvent.VK_DOWN && snake[1] < 10) y++;
        else if (e.getKeyCode() == KeyEvent.VK_LEFT && snake[0] > 0) x--;
        else if (e.getKeyCode() == KeyEvent.VK_RIGHT && snake[0] < 20) x++;

        // Update snake position
        snake[snake.length - 1] = x;
        snake[snake.length - 2] = y;

        repaint();
    }

    @Override
    public void keyReleased(KeyEvent e) {}

    @Override
    public void keyTyped(KeyEvent e) {}
}