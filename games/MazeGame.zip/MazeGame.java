import javax.swing.*;
import java.awt.*;

public class MazeGame extends JPanel implements KeyListener {
    private int x = 0;
    private int y = 0;
    package games;
    public MazeGame() {
        setPreferredSize(new Dimension(400, 400));
        setBackground(Color.BLACK);
        addKeyListener(this);
        setFocusable(true);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.WHITE);
        for (int i = 0; i < 10; i++) {
            g.fillRect(i * 40, 0, 40, 400);
            g.fillRect(0, i * 40, 400, 40);
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_UP) y--;
        else if (e.getKeyCode() == KeyEvent.VK_DOWN) y++;
        else if (e.getKeyCode() == KeyEvent.VK_LEFT) x--;
        else if (e.getKeyCode() == KeyEvent.VK_RIGHT) x++;

        repaint();
    }

    @Override
    public void keyReleased(KeyEvent e) {}

    @Override
    public void keyTyped(KeyEvent e) {}
}