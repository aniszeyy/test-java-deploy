package games;

import javax.swing.*;
import java.awt.*;

public class TennisGame extends JPanel implements KeyListener {
    private int x = 0;
    private int y = 0;

    public TennisGame() {
        setPreferredSize(new Dimension(400, 400));
        setBackground(Color.BLACK);
        addKeyListener(this);
        setFocusable(true);

        // Initialize ball position
        y = 200;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.WHITE);
        g.fillOval(x * 20, y * 20, 20, 20);
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_UP && y > 0) y--;
        else if (e.getKeyCode() == KeyEvent.VK_DOWN && y < 20) y++;
        x = (x + 1) % 20;

        repaint();
    }

    @Override
    public void keyReleased(KeyEvent e) {}

    @Override
    public void keyTyped(KeyEvent e) {}
}